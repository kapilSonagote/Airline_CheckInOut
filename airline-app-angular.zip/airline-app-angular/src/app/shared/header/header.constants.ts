export const HEADER_CONSTS = {
  HEADER_NAV_LINKS: [
    {
      label: 'Check-In',
      path: '../check-in',
    },
    {
      label: 'In-Flight',
      path: '../in-flight',
    },
  ],
  HEADER_CONSTS_ADMIN: [
    {
      label: 'Airline and passenger details for administrator',
      path: '',
    },
  ],
};
